<?php $__env->startSection('title'); ?>
<?php echo e($category->meta_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?>
<?php echo e($category->meta_description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($category->meta_keyword); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-3 py-md-5 bg-light">
    <div class="container">
        <div class="row">

            <!-- Section Title -->
            <div class="col-md-12">
                <h4 class="mb-4">Our Products</h4>
            </div>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.product.index', ['category' => $category]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3881189733-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new_proj3\myapp\resources\views/frontend/collections/products/index.blade.php ENDPATH**/ ?>