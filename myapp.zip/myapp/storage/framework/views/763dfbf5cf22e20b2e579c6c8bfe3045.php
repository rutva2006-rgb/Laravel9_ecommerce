<div>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header"><h4>Brands</h4></div>
                    <div class="card-body">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="d-block">
                                <input type="checkbox" wire:model="brandInputs" value="<?php echo e($brandItem->name); ?>"/> <?php echo e($brandItem->name); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                     </div>
                </div>
            </div>
        <div class="col-md-9">
                <div class="row">

                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <!-- Product Card -->
                        <div class="col-md-4">
                            <div class="product-card">
                                <!-- Product Image -->
                                <div class="product-card-img">
                                    <!--[if BLOCK]><![endif]--><?php if( $productsItem->quantity > 0): ?>
                                    <label class="stock bg-success">In Stock</label>
                                    <?php else: ?>
                                    <label class="stock bg-danger">Out of Stock</label>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <!--[if BLOCK]><![endif]--><?php if($productsItem->productImages->count() > 0): ?>
                                        <a href="<?php echo e(url('/collections/'.$productsItem->category->slug.'/'.$productsItem->slug)); ?>">
                                        <img src="<?php echo e(asset($productsItem->productImages[0]->image)); ?>" alt="<?php echo e($productsItem->name); ?>">
                                        </a>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <!-- Product Details -->
                                <div class="product-card-body">

                                    <p class="product-brand"><?php echo e($productsItem->brand); ?></p>

                                    <h5 class="product-name">
                                        <a href="<?php echo e(url('/collections/'.$productsItem->category->slug.'/'.$productsItem->slug)); ?>">
                                            <?php echo e($productsItem->name); ?>

                                        </a>
                                    </h5>

                                    <div class="product-prices">
                                        <span class="selling-price">$<?php echo e($productsItem->selling_price); ?></span>
                                        <span class="original-price">$<?php echo e($productsItem->original_price); ?></span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Product Card -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12">
                            <div class="p-2">
                                <h4>No Products Available for <?php echo e($category->name); ?></h4>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\new_proj\myapp\resources\views/livewire/frontend/product/index.blade.php ENDPATH**/ ?>