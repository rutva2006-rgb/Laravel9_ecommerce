@extends('layouts.admin')

@section('content')

<div class="row">
            <div class="col-md-12 grid-margin">
              <div class="flex-wrap d-flex justify-content-between">
                <div class="flex-wrap d-flex align-items-end">
                  <div class="me-md-3 me-xl-5">
                    @if(session('message'))
                    <h2 class="alert alert-success">{{ session('message') }}</h2>
                    @endif

                    <p class="mb-md-0">Your analytics dashboard template.</p>
                  </div>
                  <div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="mb-0 text-muted hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;</p>
                    <p class="mb-0 text-primary hover-cursor">Analytics</p>
                  </div>
                </div>
                <div class="flex-wrap d-flex justify-content-between align-items-end">
                  <button type="button" class="bg-white btn btn-light btn-icon me-3 d-none d-md-block ">
                    <i class="mdi mdi-download text-muted"></i>
                  </button>
                  <button type="button" class="mt-2 bg-white btn btn-light btn-icon me-3 mt-xl-0">
                    <i class="mdi mdi-clock-outline text-muted"></i>
                  </button>
                  <button type="button" class="mt-2 bg-white btn btn-light btn-icon me-3 mt-xl-0">
                    <i class="mdi mdi-plus text-muted"></i>
                  </button>
                  <button class="mt-2 btn btn-primary mt-xl-0">Generate report</button>
                </div>
              </div>
            </div>
          </div>

@endsection











