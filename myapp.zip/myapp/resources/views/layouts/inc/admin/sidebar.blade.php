<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">

    <!-- Dashboard -->
    <li class="nav-item">
      <a class="nav-link" href="/admin/dashboard">
        <i class="mdi mdi-view-dashboard menu-icon"></i>
        <span class="menu-title">Dashboard</span>
      </a>
    </li>

    <!-- Sales -->
    <li class="nav-item">
      <a class="nav-link" href="sales.html">
        <i class="mdi mdi-cash-multiple menu-icon"></i>
        <span class="menu-title">Sales</span>
      </a>
    </li>

    <!-- Category -->
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" href="#categoryMenu" aria-expanded="false" aria-controls="categoryMenu">
        <i class="mdi mdi-plus-circle menu-icon"></i>
        <span class="menu-title">Category</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="categoryMenu">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/category/create') }}">Add Category</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/category') }}">View Category</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- Products -->
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" href="#productsMenu" aria-expanded="false" aria-controls="productsMenu">
        <i class="mdi mdi-plus-circle menu-icon"></i>
        <span class="menu-title">Products</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="productsMenu">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/products/create') }}">Add Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/products') }}">View Products</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- Brands -->
    <li class="nav-item">
      <a class="nav-link" href="/admin/brands">
        <i class="mdi mdi-tag-multiple menu-icon"></i>
        <span class="menu-title">Brands</span>
      </a>
    </li>
    <!-- Brands -->
    <li class="nav-item">
      <a class="nav-link" href="/admin/colors">
        <i class="mdi mdi-tag-multiple menu-icon"></i>
        <span class="menu-title">Colors</span>
      </a>
    </li>

    <!-- Users -->
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" href="#authMenu" aria-expanded="false" aria-controls="authMenu">
        <i class="mdi mdi-account-group menu-icon"></i>
        <span class="menu-title">Users</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="authMenu">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"><a class="nav-link" href="pages/samples/login.html">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="pages/samples/login-2.html">Login 2</a></li>
          <li class="nav-item"><a class="nav-link" href="pages/samples/register.html">Register</a></li>
          <li class="nav-item"><a class="nav-link" href="pages/samples/register-2.html">Register 2</a></li>
          <li class="nav-item"><a class="nav-link" href="pages/samples/lock-screen.html">Lockscreen</a></li>
        </ul>
      </div>
    </li>

    <!-- Home Slider -->
    <li class="nav-item">
      <a class="nav-link" href="{{ url('/admin/sliders') }}">
        <i class="mdi mdi-image-album menu-icon"></i>
        <span class="menu-title">Home Slider</span>
      </a>
    </li>

    <!-- Site Setting -->
    <li class="nav-item">
      <a class="nav-link" href="#">
        <i class="mdi mdi-image-album menu-icon"></i>
        <span class="menu-title">Site Setting</span>
      </a>
    </li>

  </ul>
</nav>
